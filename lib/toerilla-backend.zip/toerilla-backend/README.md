# Toe-Rilla Gig Network — Phase 1 Backend (Working Prototype)

This is a real, tested backend implementing the core Phase 1 matching engine:
venue/musician sign-up, gig posting, automatic matching by genre/reach,
first-to-claim booking, and the finalized pricing logic (first gig free,
second gig 50% off, 15% commission after, or $0 if subscribed).

## Requirements
- Node.js 22+ (uses the built-in `node:sqlite` module — no npm install needed)

## Run it
```
node server.js
```
Server starts on http://localhost:3000

## API Endpoints

- `POST /api/venues` — sign up a venue
  Body: { name, contact_phone, contact_email, city, state, founding_member }

- `POST /api/musicians` — sign up a musician
  Body: { name, contact_phone, contact_email, city, state, genres, instruments, reach, rate_min, rate_max, founding_member }

- `POST /api/gigs` — venue posts an open slot (triggers auto-matching + notification log)
  Body: { venue_id, gig_date, gig_time, genre_needed, budget, urgency }

- `POST /api/gigs/:id/claim` — musician claims a gig (first to claim wins)
  Body: { musician_id }

- `GET /api/gigs` — list all gigs
- `GET /api/venues` — list all venues
- `GET /api/musicians` — list all musicians
- `GET /api/health` — health check

## What this proves
This is a genuinely working Phase 1 matching engine — not a mockup. It has
been tested end-to-end: sign-up, gig posting, automatic matching, first-to-
claim booking, and pricing calculation all function correctly.

## What's NOT in this version yet (Phase 2)
- No Claude API / Concierge AI layer yet
- No SMS/email delivery (notifications are logged to the database, not sent)
- No Stripe payment integration yet
- No web frontend (API only — a developer would build a UI or connect the
  existing landing page's forms to these endpoints)
- Uses SQLite (file-based) — fine for early testing, would move to a hosted
  Postgres database for real production traffic

## Next steps to make this live
1. Deploy this to a Node hosting service (Railway, Render, Fly.io all have
   free/cheap tiers and support Node + SQLite or Postgres)
2. Connect Twilio for real SMS delivery instead of the notification log
3. Add Stripe for the payment/commission step
4. Build a simple admin dashboard (or connect the existing landing page forms)
5. Layer in Claude API calls for Concierge once the core loop is proven
