const http = require('node:http');
const { URL } = require('node:url');
const db = require('./db');
const { findMatchingMusicians, calculatePricing } = require('./lib/matching');

const PORT = process.env.PORT || 3000;

function sendJSON(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data, null, 2));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => (body += chunk));
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        reject(e);
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const { pathname } = url;

  try {
    // --- Sign up a venue ---
    if (pathname === '/api/venues' && req.method === 'POST') {
      const body = await readBody(req);
      const stmt = db.prepare(`
        INSERT INTO venues (name, contact_phone, contact_email, city, state, founding_member)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const result = stmt.run(body.name, body.contact_phone, body.contact_email || null, body.city, body.state, body.founding_member ? 1 : 0);
      return sendJSON(res, 201, { id: Number(result.lastInsertRowid), message: 'Venue created' });
    }

    // --- Sign up a musician ---
    if (pathname === '/api/musicians' && req.method === 'POST') {
      const body = await readBody(req);
      const stmt = db.prepare(`
        INSERT INTO musicians (name, contact_phone, contact_email, city, state, genres, instruments, reach, rate_min, rate_max, founding_member)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      const result = stmt.run(
        body.name, body.contact_phone, body.contact_email || null, body.city, body.state,
        body.genres || '', body.instruments || '', body.reach || 'local',
        body.rate_min || null, body.rate_max || null, body.founding_member ? 1 : 0
      );
      return sendJSON(res, 201, { id: Number(result.lastInsertRowid), message: 'Musician created' });
    }

    // --- Venue posts an open gig (this triggers matching) ---
    if (pathname === '/api/gigs' && req.method === 'POST') {
      const body = await readBody(req);
      const stmt = db.prepare(`
        INSERT INTO gigs (venue_id, gig_date, gig_time, genre_needed, budget, urgency)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const result = stmt.run(
        body.venue_id, body.gig_date, body.gig_time || null,
        body.genre_needed, body.budget || null, body.urgency || 'planned'
      );
      const gigId = Number(result.lastInsertRowid);
      const gig = db.prepare('SELECT * FROM gigs WHERE id = ?').get(gigId);

      // Run the matching engine immediately
      const matches = findMatchingMusicians(gig);

      // Log notifications (in production this is where Twilio/SMS would fire)
      const logStmt = db.prepare(`
        INSERT INTO notifications_log (gig_id, musician_id, message) VALUES (?, ?, ?)
      `);
      matches.forEach(m => {
        const msg = `Toe-Rilla: New ${gig.urgency} gig — ${gig.genre_needed} needed on ${gig.gig_date}. Budget: $${gig.budget || 'TBD'}. Reply YES to claim.`;
        logStmt.run(gigId, m.id, msg);
      });

      return sendJSON(res, 201, {
        gig,
        matched_musicians_notified: matches.length,
        matches: matches.map(m => ({ id: m.id, name: m.name, genres: m.genres }))
      });
    }

    // --- Musician claims a gig (first to claim wins) ---
    if (pathname.match(/^\/api\/gigs\/\d+\/claim$/) && req.method === 'POST') {
      const gigId = Number(pathname.split('/')[3]);
      const body = await readBody(req);
      const gig = db.prepare('SELECT * FROM gigs WHERE id = ?').get(gigId);

      if (!gig) return sendJSON(res, 404, { error: 'Gig not found' });
      if (gig.status !== 'open') {
        return sendJSON(res, 409, { error: 'This gig has already been filled', filled_by: gig.matched_musician_id });
      }

      db.prepare(`
        UPDATE gigs SET status = 'filled', matched_musician_id = ?, filled_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(body.musician_id, gigId);

      const venue = db.prepare('SELECT * FROM venues WHERE id = ?').get(gig.venue_id);
      const musician = db.prepare('SELECT * FROM musicians WHERE id = ?').get(body.musician_id);
      const pricing = calculatePricing(venue, gig);

      // Increment venue's gig count
      db.prepare('UPDATE venues SET gigs_completed = gigs_completed + 1 WHERE id = ?').run(venue.id);

      return sendJSON(res, 200, {
        message: 'Gig confirmed!',
        gig_id: gigId,
        venue: { name: venue.name, contact_phone: venue.contact_phone },
        musician: { name: musician.name, contact_phone: musician.contact_phone },
        pricing
      });
    }

    // --- List open gigs (for testing / dashboard) ---
    if (pathname === '/api/gigs' && req.method === 'GET') {
      const gigs = db.prepare('SELECT * FROM gigs ORDER BY created_at DESC').all();
      return sendJSON(res, 200, gigs);
    }

    // --- List venues / musicians (for testing) ---
    if (pathname === '/api/venues' && req.method === 'GET') {
      return sendJSON(res, 200, db.prepare('SELECT * FROM venues').all());
    }
    if (pathname === '/api/musicians' && req.method === 'GET') {
      return sendJSON(res, 200, db.prepare('SELECT * FROM musicians').all());
    }

    // --- Health check ---
    if (pathname === '/api/health') {
      return sendJSON(res, 200, { status: 'ok', service: 'Toe-Rilla Gig Network API' });
    }

    sendJSON(res, 404, { error: 'Not found' });
  } catch (err) {
    console.error(err);
    sendJSON(res, 500, { error: err.message });
  }
});

server.listen(PORT, () => {
  console.log(`Toe-Rilla API running on http://localhost:${PORT}`);
});
